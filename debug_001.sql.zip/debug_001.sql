-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 17, 2021 at 03:08 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `debug_001`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `order`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(3, NULL, 1, 'Phones', 'phones', '2020-11-13 05:13:00', '2020-12-15 11:20:54'),
(4, 10, 1, 'laptops', 'laptops', '2020-11-13 05:14:17', '2020-12-14 00:42:40'),
(5, NULL, 1, 'Appliances', 'eletronics', '2020-11-13 05:15:55', '2020-12-15 11:20:03'),
(6, 5, 1, 'Home', 'home', '2020-11-13 05:16:24', '2020-12-15 11:20:26'),
(7, 12, 1, 'men', 'men', '2020-11-13 05:16:36', '2020-12-14 00:41:26'),
(8, 7, 1, 'shoe', 'shoe', '2020-11-13 05:16:57', '2020-11-13 05:16:57'),
(9, 3, 1, 'Android', 'android-phones', '2020-12-14 00:27:50', '2020-12-14 00:43:47'),
(10, NULL, 1, 'Computers', 'computers', '2020-12-14 00:32:12', '2020-12-14 00:42:25'),
(11, 3, 1, 'iPhones', 'iphones', '2020-12-14 00:37:25', '2020-12-14 00:37:25'),
(12, NULL, 1, 'Fashion', 'fashion', '2020-12-14 00:41:14', '2020-12-14 00:41:14'),
(13, 10, 1, 'Desktop', 'desktop', '2020-12-14 00:43:07', '2020-12-14 00:43:07'),
(15, 6, 1, 'Television', 'television', '2020-12-14 00:45:22', '2020-12-15 11:23:26'),
(16, 12, 1, 'Women', 'women', '2020-12-15 10:32:04', '2020-12-15 11:09:22'),
(17, 12, 1, 'Kids', 'kids', '2020-12-15 10:32:15', '2020-12-15 11:16:15'),
(19, NULL, 1, 'Toileteries', 'toileteries', '2020-12-15 10:32:43', '2020-12-15 10:32:43'),
(21, 24, 1, 'Toys', 'toys', '2020-12-15 10:33:33', '2020-12-15 11:16:45'),
(23, 6, 1, 'DVD Player', 'dvd-player', '2020-12-15 10:35:35', '2020-12-15 11:23:04'),
(24, NULL, 1, 'Other', 'other', '2020-12-15 10:38:55', '2020-12-15 10:38:55'),
(25, NULL, 1, 'Decoration', 'decoration', '2020-12-15 10:39:10', '2020-12-15 10:39:10'),
(26, 19, 1, 'Perfume', 'perfume', '2020-12-15 10:39:33', '2020-12-15 10:39:33'),
(27, 19, 1, 'Colonge', 'colonge', '2020-12-15 10:39:47', '2020-12-15 10:39:47'),
(28, 19, 1, 'Cream', 'cream', '2020-12-15 10:40:12', '2020-12-15 10:40:12'),
(29, 19, 1, 'Shampoo', 'shampoo', '2020-12-15 10:42:01', '2020-12-15 10:42:01'),
(31, 13, 1, 'Servers', 'servers', '2020-12-15 10:43:32', '2020-12-15 10:43:32'),
(32, 7, 1, 'Shirt', 'shirt', '2020-12-15 10:46:13', '2020-12-15 10:46:13'),
(33, 7, 1, 'Trousers', 'trousers', '2020-12-15 10:46:32', '2020-12-15 10:46:32'),
(34, 4, 1, 'Lenovo', 'lenovo', '2020-12-15 11:10:41', '2020-12-15 11:10:41'),
(35, 4, 1, 'Dell', 'dell', '2020-12-15 11:10:59', '2020-12-15 11:10:59'),
(36, 4, 1, 'Hewlett Packard', 'hewlett-packard', '2020-12-15 11:11:18', '2020-12-15 11:11:18'),
(37, 10, 1, 'Accessories', 'accessories', '2020-12-15 11:11:45', '2020-12-15 11:11:45'),
(38, 37, 1, 'HDD', 'hdd', '2020-12-15 11:12:01', '2020-12-15 11:12:01'),
(39, 37, 1, 'SSD', 'ssd', '2020-12-15 11:12:16', '2020-12-15 11:12:16'),
(40, 37, 1, 'Keyboard', 'keyboard', '2020-12-15 11:12:37', '2020-12-15 11:12:37'),
(41, 37, 1, 'Mouse', 'mouse', '2020-12-15 11:13:02', '2020-12-15 11:13:02'),
(42, 4, 1, 'MacBooks', 'macbooks', '2020-12-15 11:14:02', '2020-12-15 11:14:02'),
(43, 13, 1, 'iMacs', 'imacs', '2020-12-15 11:14:21', '2020-12-15 11:14:21'),
(44, 16, 1, 'Skirts', 'skirts', '2020-12-15 11:17:43', '2020-12-15 11:17:43'),
(45, 16, 1, 'Make Ups', 'make-ups', '2020-12-15 11:18:06', '2020-12-15 11:18:06'),
(46, 16, 1, 'Shoes', 'shoes', '2020-12-15 11:18:33', '2020-12-15 11:18:33'),
(47, 9, 1, 'Samsung', 'samsung', '2020-12-15 11:23:54', '2020-12-15 11:26:22'),
(48, 9, 1, 'Xiaomi', 'xiaomi', '2020-12-15 11:24:16', '2020-12-15 11:24:16'),
(51, 9, 1, 'Huawei', 'huawei', '2020-12-15 11:25:06', '2020-12-15 11:25:06'),
(52, 9, 1, 'Vivo', 'vivo', '2020-12-15 11:25:24', '2020-12-15 11:25:24'),
(53, 9, 1, 'Tecno', 'tecno', '2020-12-15 11:25:40', '2020-12-15 11:25:40'),
(54, 9, 1, 'iTel', 'itel', '2020-12-15 11:25:56', '2020-12-15 11:25:56'),
(55, 11, 1, '12 Pro Max', '12-pro-max', '2020-12-15 11:26:48', '2020-12-15 11:26:48'),
(56, 11, 1, '11 Pro Max', '11-pro-max', '2020-12-15 11:27:03', '2020-12-15 11:27:03'),
(57, 11, 1, 'XR', 'xr', '2020-12-15 11:27:22', '2020-12-15 11:27:22'),
(58, 11, 1, 'iPhone 8 Plus', 'iphone-8-plus', '2020-12-15 11:27:48', '2020-12-15 11:27:48'),
(59, 6, 1, 'Fan', 'fan', '2020-12-15 11:28:39', '2020-12-15 11:28:39'),
(60, 6, 1, 'Home Theatre', 'home-theatre', '2020-12-15 11:28:59', '2020-12-15 11:28:59'),
(61, 26, 1, 'Suvauge', 'suvauge', '2020-12-15 11:29:46', '2020-12-15 11:29:46'),
(62, 26, 1, 'History', 'history', '2020-12-15 11:30:02', '2020-12-15 11:30:02'),
(63, 26, 1, 'White Diamonds', 'white-diamonds', '2020-12-15 11:30:21', '2020-12-15 11:30:21'),
(64, 26, 1, 'Armani', 'armani', '2020-12-15 11:31:05', '2020-12-15 11:31:05'),
(65, 27, 1, 'Cein', 'cein', '2020-12-15 11:31:23', '2020-12-15 11:31:23'),
(66, 27, 1, 'Sure', 'sure', '2020-12-15 11:31:35', '2020-12-15 11:31:35'),
(67, 27, 1, 'Old Spice', 'old-spice', '2020-12-15 11:32:02', '2020-12-15 11:32:02'),
(69, 27, 1, 'Speed', 'speed', '2020-12-15 11:32:39', '2020-12-15 11:32:39'),
(70, 27, 1, 'Nivea', 'nivea', '2020-12-15 11:32:58', '2020-12-15 11:32:58'),
(71, 13, 1, 'All In One', 'all-in-one', '2020-12-15 11:33:46', '2020-12-15 11:33:46'),
(72, 11, 1, 'iPhone 8', 'iphone-8', '2020-12-15 11:34:16', '2020-12-15 11:34:16'),
(73, 13, 1, 'KMVs', 'kmvs', '2020-12-15 11:35:24', '2020-12-15 11:35:24'),
(74, NULL, 1, 'Furnitures', 'furnitures', '2020-12-15 11:37:41', '2020-12-15 11:37:41');

-- --------------------------------------------------------

--
-- Table structure for table `data_rows`
--

CREATE TABLE `data_rows` (
  `id` int(10) UNSIGNED NOT NULL,
  `data_type_id` int(10) UNSIGNED NOT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `browse` tinyint(1) NOT NULL DEFAULT 1,
  `read` tinyint(1) NOT NULL DEFAULT 1,
  `edit` tinyint(1) NOT NULL DEFAULT 1,
  `add` tinyint(1) NOT NULL DEFAULT 1,
  `delete` tinyint(1) NOT NULL DEFAULT 1,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`) VALUES
(1, 1, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(2, 1, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(3, 1, 'email', 'text', 'Email', 1, 1, 1, 1, 1, 1, NULL, 3),
(4, 1, 'password', 'password', 'Password', 1, 0, 0, 1, 1, 0, NULL, 4),
(5, 1, 'remember_token', 'text', 'Remember Token', 0, 0, 0, 0, 0, 0, NULL, 5),
(6, 1, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, NULL, 6),
(7, 1, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 7),
(8, 1, 'avatar', 'image', 'Avatar', 0, 1, 1, 1, 1, 1, NULL, 8),
(9, 1, 'user_belongsto_role_relationship', 'relationship', 'Role', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":0}', 10),
(10, 1, 'user_belongstomany_role_relationship', 'relationship', 'Roles', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}', 11),
(11, 1, 'settings', 'hidden', 'Settings', 0, 0, 0, 0, 0, 0, NULL, 12),
(12, 2, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(13, 2, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(14, 2, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(15, 2, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(16, 3, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(17, 3, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(18, 3, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(19, 3, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(20, 3, 'display_name', 'text', 'Display Name', 1, 1, 1, 1, 1, 1, NULL, 5),
(21, 1, 'role_id', 'text', 'Role', 1, 1, 1, 1, 1, 1, NULL, 9),
(22, 4, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, '{}', 1),
(23, 4, 'parent_id', 'select_dropdown', 'Parent', 0, 1, 1, 1, 1, 1, '{\"default\":\"\",\"null\":\"\",\"options\":{\"\":\"-- None --\"},\"relationship\":{\"key\":\"id\",\"label\":\"name\"}}', 2),
(24, 4, 'order', 'text', 'Order', 1, 1, 1, 1, 1, 1, '{\"default\":1}', 3),
(25, 4, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 4),
(26, 4, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"name\"}}', 5),
(27, 4, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 6),
(28, 4, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(29, 5, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(30, 5, 'author_id', 'text', 'Author', 1, 0, 1, 1, 0, 1, NULL, 2),
(31, 5, 'category_id', 'text', 'Category', 1, 0, 1, 1, 1, 0, NULL, 3),
(32, 5, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, NULL, 4),
(33, 5, 'excerpt', 'text_area', 'Excerpt', 1, 0, 1, 1, 1, 1, NULL, 5),
(34, 5, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, NULL, 6),
(35, 5, 'image', 'image', 'Post Image', 0, 1, 1, 1, 1, 1, '{\"resize\":{\"width\":\"1000\",\"height\":\"null\"},\"quality\":\"70%\",\"upsize\":true,\"thumbnails\":[{\"name\":\"medium\",\"scale\":\"50%\"},{\"name\":\"small\",\"scale\":\"25%\"},{\"name\":\"cropped\",\"crop\":{\"width\":\"300\",\"height\":\"250\"}}]}', 7),
(36, 5, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\",\"forceUpdate\":true},\"validation\":{\"rule\":\"unique:posts,slug\"}}', 8),
(37, 5, 'meta_description', 'text_area', 'Meta Description', 1, 0, 1, 1, 1, 1, NULL, 9),
(38, 5, 'meta_keywords', 'text_area', 'Meta Keywords', 1, 0, 1, 1, 1, 1, NULL, 10),
(39, 5, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"DRAFT\",\"options\":{\"PUBLISHED\":\"published\",\"DRAFT\":\"draft\",\"PENDING\":\"pending\"}}', 11),
(40, 5, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, NULL, 12),
(41, 5, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 13),
(42, 5, 'seo_title', 'text', 'SEO Title', 0, 1, 1, 1, 1, 1, NULL, 14),
(43, 5, 'featured', 'checkbox', 'Featured', 1, 1, 1, 1, 1, 1, NULL, 15),
(44, 6, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(45, 6, 'author_id', 'text', 'Author', 1, 0, 0, 0, 0, 0, NULL, 2),
(46, 6, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, NULL, 3),
(47, 6, 'excerpt', 'text_area', 'Excerpt', 1, 0, 1, 1, 1, 1, NULL, 4),
(48, 6, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, NULL, 5),
(49, 6, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\"},\"validation\":{\"rule\":\"unique:pages,slug\"}}', 6),
(50, 6, 'meta_description', 'text', 'Meta Description', 1, 0, 1, 1, 1, 1, NULL, 7),
(51, 6, 'meta_keywords', 'text', 'Meta Keywords', 1, 0, 1, 1, 1, 1, NULL, 8),
(52, 6, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"INACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 9),
(53, 6, 'created_at', 'timestamp', 'Created At', 1, 1, 1, 0, 0, 0, NULL, 10),
(54, 6, 'updated_at', 'timestamp', 'Updated At', 1, 0, 0, 0, 0, 0, NULL, 11),
(55, 6, 'image', 'image', 'Page Image', 0, 1, 1, 1, 1, 1, NULL, 12),
(64, 8, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 3),
(65, 8, 'description', 'text', 'Description', 1, 1, 1, 1, 1, 1, '{}', 4),
(66, 8, 'price', 'text', 'Price', 1, 1, 1, 1, 1, 1, '{}', 5),
(67, 8, 'cover_img', 'image', 'Cover Img', 0, 1, 1, 1, 1, 1, '{}', 6),
(68, 8, 'id', 'text', 'Id', 1, 1, 1, 0, 0, 0, '{}', 1),
(69, 8, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 7),
(70, 8, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(71, 8, 'shop_id', 'text', 'Shop Id', 0, 1, 1, 1, 1, 1, '{}', 2),
(72, 9, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(73, 9, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 3),
(74, 9, 'user_id', 'text', 'User Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(75, 9, 'is_active', 'checkbox', 'Is Active', 1, 1, 1, 1, 1, 1, '{\"on\":\"Active\",\"off\":\"Not Active\",\"checked\":\"true\"}', 4),
(76, 9, 'description', 'text', 'Description', 0, 1, 1, 1, 1, 1, '{}', 5),
(77, 9, 'rating', 'text', 'Rating', 0, 1, 1, 1, 1, 1, '{}', 6),
(78, 9, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 7),
(79, 9, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(80, 10, 'id', 'text', 'Id', 1, 1, 0, 0, 0, 0, '{}', 1),
(81, 10, 'order_number', 'text', 'Order Number', 1, 0, 1, 1, 1, 1, '{}', 3),
(82, 10, 'user_id', 'text', 'User Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(83, 10, 'status', 'text', 'Status', 1, 1, 1, 1, 1, 1, '{}', 4),
(84, 10, 'grand_total', 'text', 'Grand Total', 1, 1, 1, 1, 1, 1, '{}', 5),
(85, 10, 'item_count', 'text', 'Item Count', 1, 1, 1, 1, 1, 1, '{}', 6),
(86, 10, 'is_paid', 'text', 'Is Paid', 1, 1, 1, 1, 1, 1, '{}', 7),
(87, 10, 'payment_method', 'text', 'Payment Method', 1, 1, 1, 1, 1, 1, '{}', 8),
(88, 10, 'shipping_fullname', 'text', 'Shipping Fullname', 1, 1, 1, 1, 1, 1, '{}', 9),
(89, 10, 'shipping_address', 'text', 'Shipping Address', 1, 1, 1, 1, 1, 1, '{}', 10),
(90, 10, 'shipping_city', 'text', 'Shipping City', 1, 0, 0, 0, 0, 0, '{}', 11),
(91, 10, 'shipping_state', 'text', 'Shipping State', 1, 0, 0, 0, 0, 0, '{}', 12),
(92, 10, 'shipping_zipcode', 'text', 'Shipping Zipcode', 1, 0, 0, 0, 0, 0, '{}', 13),
(93, 10, 'shipping_phone', 'text', 'Shipping Phone', 1, 0, 1, 1, 1, 1, '{}', 14),
(94, 10, 'notes', 'text', 'Notes', 0, 0, 0, 0, 0, 0, '{}', 15),
(95, 10, 'billing_fullname', 'text', 'Billing Fullname', 1, 0, 0, 0, 0, 0, '{}', 16),
(96, 10, 'billing_address', 'text', 'Billing Address', 1, 0, 0, 0, 0, 0, '{}', 17),
(97, 10, 'billing_city', 'text', 'Billing City', 1, 0, 0, 0, 0, 0, '{}', 18),
(98, 10, 'billing_state', 'text', 'Billing State', 1, 0, 0, 0, 0, 0, '{}', 19),
(99, 10, 'billing_zipcode', 'text', 'Billing Zipcode', 1, 0, 0, 0, 0, 0, '{}', 20),
(100, 10, 'billing_phone', 'text', 'Billing Phone', 1, 0, 0, 0, 0, 0, '{}', 21),
(101, 10, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 22),
(102, 10, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 23),
(103, 9, 'shop_belongsto_user_relationship', 'relationship', 'users', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"user_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(104, 8, 'product_belongsto_shop_relationship', 'relationship', 'shops', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Shop\",\"table\":\"shops\",\"type\":\"belongsTo\",\"column\":\"shop_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(105, 8, 'product_belongstomany_category_relationship', 'relationship', 'categories', 0, 1, 1, 1, 1, 1, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Category\",\"table\":\"categories\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"product_categories\",\"pivot\":\"1\",\"taggable\":\"on\"}', 10),
(106, 14, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 3),
(107, 14, 'description', 'text', 'Description', 1, 1, 1, 1, 1, 1, '{}', 4),
(108, 14, 'price', 'text', 'Price', 1, 1, 1, 1, 1, 1, '{}', 5),
(109, 14, 'cover_img', 'image', 'Cover Img', 0, 1, 1, 1, 1, 1, '{}', 6),
(110, 14, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(111, 14, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 7),
(112, 14, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(113, 14, 'shop_id', 'text', 'Shop Id', 0, 1, 1, 1, 1, 1, '{}', 2),
(115, 10, 'order_belongsto_user_relationship', 'relationship', 'users', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 24);

-- --------------------------------------------------------

--
-- Table structure for table `data_types`
--

CREATE TABLE `data_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT 0,
  `server_side` tinyint(4) NOT NULL DEFAULT 0,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_types`
--

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `policy_name`, `controller`, `description`, `generate_permissions`, `server_side`, `details`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users', 'User', 'Users', 'voyager-person', 'TCG\\Voyager\\Models\\User', 'TCG\\Voyager\\Policies\\UserPolicy', 'TCG\\Voyager\\Http\\Controllers\\VoyagerUserController', '', 1, 0, NULL, '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(2, 'menus', 'menus', 'Menu', 'Menus', 'voyager-list', 'TCG\\Voyager\\Models\\Menu', NULL, '', '', 1, 0, NULL, '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(3, 'roles', 'roles', 'Role', 'Roles', 'voyager-lock', 'TCG\\Voyager\\Models\\Role', NULL, 'TCG\\Voyager\\Http\\Controllers\\VoyagerRoleController', '', 1, 0, NULL, '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(4, 'categories', 'categories', 'Category', 'Categories', 'voyager-categories', 'TCG\\Voyager\\Models\\Category', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"desc\",\"default_search_key\":null,\"scope\":null}', '2020-10-29 08:24:48', '2020-11-13 05:17:21'),
(5, 'posts', 'posts', 'Post', 'Posts', 'voyager-news', 'TCG\\Voyager\\Models\\Post', 'TCG\\Voyager\\Policies\\PostPolicy', '', '', 1, 0, NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(6, 'pages', 'pages', 'Page', 'Pages', 'voyager-file-text', 'TCG\\Voyager\\Models\\Page', NULL, '', '', 1, 0, NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(8, 'products', 'products', 'Product', 'Products', 'voyager-bag', 'App\\Product', 'App\\Policies\\ProductPolicy', 'App\\Http\\Controllers\\Admin\\ProductController', NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2020-10-29 08:35:21', '2020-12-12 22:50:24'),
(9, 'shops', 'shops', 'Shop', 'Shops', 'voyager-shop', 'App\\Shop', NULL, 'App\\Http\\Controllers\\Admin\\ShopController', NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2020-10-29 08:36:48', '2020-10-29 09:22:05'),
(10, 'orders', 'orders', 'Order', 'Orders', 'voyager-list', 'App\\Order', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2020-10-29 08:38:28', '2020-12-14 20:52:11'),
(14, 'recents', 'recents', 'Recent', 'Recents', 'voyager-calendar', 'App\\Recent', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2020-11-13 15:02:51', '2020-12-14 20:59:31');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2020-10-29 08:24:47', '2020-10-29 08:24:47');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`) VALUES
(1, 1, 'Dashboard', '', '_self', 'voyager-boat', NULL, NULL, 1, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.dashboard', NULL),
(2, 1, 'Media', '', '_self', 'voyager-images', NULL, NULL, 5, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.media.index', NULL),
(3, 1, 'Users', '', '_self', 'voyager-person', NULL, NULL, 3, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.users.index', NULL),
(4, 1, 'Roles', '', '_self', 'voyager-lock', NULL, NULL, 2, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.roles.index', NULL),
(5, 1, 'Tools', '', '_self', 'voyager-tools', NULL, NULL, 9, '2020-10-29 08:24:47', '2020-10-29 08:24:47', NULL, NULL),
(6, 1, 'Menu Builder', '', '_self', 'voyager-list', NULL, 5, 10, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.menus.index', NULL),
(7, 1, 'Database', '', '_self', 'voyager-data', NULL, 5, 11, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.database.index', NULL),
(8, 1, 'Compass', '', '_self', 'voyager-compass', NULL, 5, 12, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.compass.index', NULL),
(9, 1, 'BREAD', '', '_self', 'voyager-bread', NULL, 5, 13, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.bread.index', NULL),
(10, 1, 'Settings', '', '_self', 'voyager-settings', NULL, NULL, 14, '2020-10-29 08:24:47', '2020-10-29 08:24:47', 'voyager.settings.index', NULL),
(11, 1, 'Categories', '', '_self', 'voyager-categories', NULL, NULL, 8, '2020-10-29 08:24:48', '2020-10-29 08:24:48', 'voyager.categories.index', NULL),
(12, 1, 'Posts', '', '_self', 'voyager-news', NULL, NULL, 6, '2020-10-29 08:24:48', '2020-10-29 08:24:48', 'voyager.posts.index', NULL),
(13, 1, 'Pages', '', '_self', 'voyager-file-text', NULL, NULL, 7, '2020-10-29 08:24:49', '2020-10-29 08:24:49', 'voyager.pages.index', NULL),
(14, 1, 'Hooks', '', '_self', 'voyager-hook', NULL, 5, 13, '2020-10-29 08:24:49', '2020-10-29 08:24:49', 'voyager.hooks', NULL),
(16, 1, 'Products', '', '_self', 'voyager-bag', NULL, NULL, 16, '2020-10-29 08:35:21', '2020-10-29 08:35:21', 'voyager.products.index', NULL),
(17, 1, 'Shops', '', '_self', 'voyager-shop', NULL, NULL, 17, '2020-10-29 08:36:48', '2020-10-29 08:36:48', 'voyager.shops.index', NULL),
(18, 1, 'Orders', '', '_self', 'voyager-list', NULL, NULL, 18, '2020-10-29 08:38:28', '2020-10-29 08:38:28', 'voyager.orders.index', NULL),
(19, 1, 'Recents', '', '_self', 'voyager-calendar', NULL, NULL, 19, '2020-11-13 15:02:51', '2020-11-13 15:02:51', 'voyager.recents.index', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_01_000000_add_voyager_user_fields', 1),
(4, '2016_01_01_000000_create_data_types_table', 1),
(5, '2016_01_01_000000_create_pages_table', 1),
(6, '2016_01_01_000000_create_posts_table', 1),
(7, '2016_02_15_204651_create_categories_table', 1),
(8, '2016_05_19_173453_create_menu_table', 1),
(9, '2016_10_21_190000_create_roles_table', 1),
(10, '2016_10_21_190000_create_settings_table', 1),
(11, '2016_11_30_135954_create_permission_table', 1),
(12, '2016_11_30_141208_create_permission_role_table', 1),
(13, '2016_12_26_201236_data_types__add__server_side', 1),
(14, '2017_01_13_000000_add_route_to_menu_items_table', 1),
(15, '2017_01_14_005015_create_translations_table', 1),
(16, '2017_01_15_000000_make_table_name_nullable_in_permissions_table', 1),
(17, '2017_03_06_000000_add_controller_to_data_types_table', 1),
(18, '2017_04_11_000000_alter_post_nullable_fields_table', 1),
(19, '2017_04_21_000000_add_order_to_data_rows_table', 1),
(20, '2017_07_05_210000_add_policyname_to_data_types_table', 1),
(21, '2017_08_05_000000_add_group_to_settings_table', 1),
(22, '2017_11_26_013050_add_user_role_relationship', 1),
(23, '2017_11_26_015000_create_user_roles_table', 1),
(24, '2018_03_11_000000_add_user_settings', 1),
(25, '2018_03_14_000000_add_details_to_data_types_table', 1),
(26, '2018_03_16_000000_make_settings_value_nullable', 1),
(27, '2019_08_19_000000_create_failed_jobs_table', 1),
(28, '2020_06_21_110546_create_shops_table', 1),
(29, '2020_06_22_025844_create_products_table', 1),
(30, '2020_06_28_003301_create_orders_table', 1),
(31, '2020_08_10_141718_orders', 1),
(32, '2020_08_10_141810_products', 1),
(33, '2020_09_11_041802_create_order_items_table', 1),
(34, '2020_11_13_045131_create-_product_categories_table', 2),
(35, '2020_11_13_132416_create_purchase_table', 3),
(36, '2020_11_13_135458_create_purchahe_tables_table', 4),
(37, '2020_11_13_143810_create_purchaseds_table', 5),
(41, '2020_11_13_143917_create_recents_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('pending','processing','completed','decline') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `grand_total` double(8,2) NOT NULL,
  `item_count` int(11) NOT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `payment_method` enum('cash_on_delivery','paypal','stripe','card') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash_on_delivery',
  `shipping_fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_number`, `user_id`, `status`, `grand_total`, `item_count`, `is_paid`, `payment_method`, `shipping_fullname`, `shipping_address`, `shipping_phone`, `notes`, `billing_fullname`, `billing_address`, `billing_phone`, `created_at`, `updated_at`) VALUES
(1, 'orderNumber-5f9a86da76e60', 3, 'pending', 4872.00, 1, 0, 'cash_on_delivery', 'Eugene John', '86 Soldier Street freetown', '+23278814080', NULL, 'Eugene John', '86 Soldier Street freetown', '+23278814080', '2020-10-29 09:09:46', '2020-10-29 09:09:46'),
(2, 'orderNumber-5fb98fd025f7e', 1, 'pending', 20000.00, 1, 0, 'cash_on_delivery', 'Ibrahim Ivan Kargbo', '23 Cemetery Road Ogoo Farm', '030009366', NULL, 'Ibrahim Ivan Kargbo', '23 Cemetery Road Ogoo Farm', '030009366', '2020-11-21 22:08:16', '2020-11-21 22:08:16'),
(3, 'orderNumber-5fbac291bf8be', 1, 'pending', 3220.00, 1, 0, 'cash_on_delivery', 'John Salifu Ston', 'Off old school imatt', '23230009366', NULL, 'John Salifu Ston', 'Off old school imatt', '23230009366', '2020-11-22 19:57:05', '2020-11-22 19:57:05'),
(87, 'orderNumber-60520d23dfe30', 1, 'pending', 900000.00, 1, 0, 'cash_on_delivery', 'Mohamed Tholley', 'Customs water quay', '+23230009366', NULL, 'Mohamed Tholley', 'Customs water quay', '+23230009366', '2021-03-17 14:07:31', '2021-03-17 14:07:31');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `price` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `price`, `quantity`, `created_at`, `updated_at`) VALUES
(2, 2, 152, 20000.00, 1, NULL, NULL),
(3, 3, 39, 3220.00, 1, NULL, NULL),
(5, 87, 39, 900000.00, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `author_id`, `title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `created_at`, `updated_at`) VALUES
(1, 0, 'Hello World', 'Hang the jib grog grog blossom grapple dance the hempen jig gangway pressgang bilge rat to go on account lugger. Nelsons folly gabion line draught scallywag fire ship gaff fluke fathom case shot. Sea Legs bilge rat sloop matey gabion long clothes run a shot across the bow Gold Road cog league.', '<p>Hello World. Scallywag grog swab Cat o\'nine tails scuttle rigging hardtack cable nipper Yellow Jack. Handsomely spirits knave lad killick landlubber or just lubber deadlights chantey pinnace crack Jennys tea cup. Provost long clothes black spot Yellow Jack bilged on her anchor league lateen sail case shot lee tackle.</p>\n<p>Ballast spirits fluke topmast me quarterdeck schooner landlubber or just lubber gabion belaying pin. Pinnace stern galleon starboard warp carouser to go on account dance the hempen jig jolly boat measured fer yer chains. Man-of-war fire in the hole nipperkin handsomely doubloon barkadeer Brethren of the Coast gibbet driver squiffy.</p>', 'pages/page1.jpg', 'hello-world', 'Yar Meta Description', 'Keyword1, Keyword2', 'ACTIVE', '2020-10-29 08:24:49', '2020-10-29 08:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'browse_admin', NULL, '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(2, 'browse_bread', NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(3, 'browse_database', NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(4, 'browse_media', NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(5, 'browse_compass', NULL, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(6, 'browse_menus', 'menus', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(7, 'read_menus', 'menus', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(8, 'edit_menus', 'menus', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(9, 'add_menus', 'menus', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(10, 'delete_menus', 'menus', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(11, 'browse_roles', 'roles', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(12, 'read_roles', 'roles', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(13, 'edit_roles', 'roles', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(14, 'add_roles', 'roles', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(15, 'delete_roles', 'roles', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(16, 'browse_users', 'users', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(17, 'read_users', 'users', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(18, 'edit_users', 'users', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(19, 'add_users', 'users', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(20, 'delete_users', 'users', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(21, 'browse_settings', 'settings', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(22, 'read_settings', 'settings', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(23, 'edit_settings', 'settings', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(24, 'add_settings', 'settings', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(25, 'delete_settings', 'settings', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(26, 'browse_categories', 'categories', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(27, 'read_categories', 'categories', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(28, 'edit_categories', 'categories', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(29, 'add_categories', 'categories', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(30, 'delete_categories', 'categories', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(31, 'browse_posts', 'posts', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(32, 'read_posts', 'posts', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(33, 'edit_posts', 'posts', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(34, 'add_posts', 'posts', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(35, 'delete_posts', 'posts', '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(36, 'browse_pages', 'pages', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(37, 'read_pages', 'pages', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(38, 'edit_pages', 'pages', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(39, 'add_pages', 'pages', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(40, 'delete_pages', 'pages', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(41, 'browse_hooks', NULL, '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(47, 'browse_products', 'products', '2020-10-29 08:35:21', '2020-10-29 08:35:21'),
(48, 'read_products', 'products', '2020-10-29 08:35:21', '2020-10-29 08:35:21'),
(49, 'edit_products', 'products', '2020-10-29 08:35:21', '2020-10-29 08:35:21'),
(50, 'add_products', 'products', '2020-10-29 08:35:21', '2020-10-29 08:35:21'),
(51, 'delete_products', 'products', '2020-10-29 08:35:21', '2020-10-29 08:35:21'),
(52, 'browse_shops', 'shops', '2020-10-29 08:36:48', '2020-10-29 08:36:48'),
(53, 'read_shops', 'shops', '2020-10-29 08:36:48', '2020-10-29 08:36:48'),
(54, 'edit_shops', 'shops', '2020-10-29 08:36:48', '2020-10-29 08:36:48'),
(55, 'add_shops', 'shops', '2020-10-29 08:36:48', '2020-10-29 08:36:48'),
(56, 'delete_shops', 'shops', '2020-10-29 08:36:48', '2020-10-29 08:36:48'),
(57, 'browse_orders', 'orders', '2020-10-29 08:38:28', '2020-10-29 08:38:28'),
(58, 'read_orders', 'orders', '2020-10-29 08:38:28', '2020-10-29 08:38:28'),
(59, 'edit_orders', 'orders', '2020-10-29 08:38:28', '2020-10-29 08:38:28'),
(60, 'add_orders', 'orders', '2020-10-29 08:38:28', '2020-10-29 08:38:28'),
(61, 'delete_orders', 'orders', '2020-10-29 08:38:28', '2020-10-29 08:38:28'),
(62, 'browse_recents', 'recents', '2020-11-13 15:02:51', '2020-11-13 15:02:51'),
(63, 'read_recents', 'recents', '2020-11-13 15:02:51', '2020-11-13 15:02:51'),
(64, 'edit_recents', 'recents', '2020-11-13 15:02:51', '2020-11-13 15:02:51'),
(65, 'add_recents', 'recents', '2020-11-13 15:02:51', '2020-11-13 15:02:51'),
(66, 'delete_recents', 'recents', '2020-11-13 15:02:51', '2020-11-13 15:02:51');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 3),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(47, 1),
(47, 3),
(48, 1),
(48, 3),
(49, 1),
(49, 3),
(50, 1),
(50, 3),
(51, 1),
(51, 3),
(52, 1),
(52, 3),
(53, 1),
(53, 3),
(54, 1),
(54, 3),
(55, 1),
(56, 1),
(56, 3),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `author_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `category_id`, `title`, `seo_title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `featured`, `created_at`, `updated_at`) VALUES
(1, 0, NULL, 'Lorem Ipsum Post', NULL, 'This is the excerpt for the Lorem Ipsum Post', '<p>This is the body of the lorem ipsum post</p>', 'posts/post1.jpg', 'lorem-ipsum-post', 'This is the meta description', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(2, 0, NULL, 'My Sample Post', NULL, 'This is the excerpt for the sample Post', '<p>This is the body for the sample post, which includes the body.</p>\n                <h2>We can use all kinds of format!</h2>\n                <p>And include a bunch of other stuff.</p>', 'posts/post2.jpg', 'my-sample-post', 'Meta Description for sample post', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(3, 0, NULL, 'Latest Post', NULL, 'This is the excerpt for the latest post', '<p>This is the body for the latest post</p>', 'posts/post3.jpg', 'latest-post', 'This is the meta description', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2020-10-29 08:24:48', '2020-10-29 08:24:48'),
(4, 0, NULL, 'Yarr Post', NULL, 'Reef sails nipperkin bring a spring upon her cable coffer jury mast spike marooned Pieces of Eight poop deck pillage. Clipper driver coxswain galleon hempen halter come about pressgang gangplank boatswain swing the lead. Nipperkin yard skysail swab lanyard Blimey bilge water ho quarter Buccaneer.', '<p>Swab deadlights Buccaneer fire ship square-rigged dance the hempen jig weigh anchor cackle fruit grog furl. Crack Jennys tea cup chase guns pressgang hearties spirits hogshead Gold Road six pounders fathom measured fer yer chains. Main sheet provost come about trysail barkadeer crimp scuttle mizzenmast brig plunder.</p>\n<p>Mizzen league keelhaul galleon tender cog chase Barbary Coast doubloon crack Jennys tea cup. Blow the man down lugsail fire ship pinnace cackle fruit line warp Admiral of the Black strike colors doubloon. Tackle Jack Ketch come about crimp rum draft scuppers run a shot across the bow haul wind maroon.</p>\n<p>Interloper heave down list driver pressgang holystone scuppers tackle scallywag bilged on her anchor. Jack Tar interloper draught grapple mizzenmast hulk knave cable transom hogshead. Gaff pillage to go on account grog aft chase guns piracy yardarm knave clap of thunder.</p>', 'posts/post4.jpg', 'yarr-post', 'this be a meta descript', 'keyword1, keyword2, keyword3', 'PUBLISHED', 0, '2020-10-29 08:24:48', '2020-10-29 08:24:48');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `cover_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shop_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`name`, `description`, `price`, `cover_img`, `id`, `created_at`, `updated_at`, `shop_id`) VALUES
('JBL Bluetooth Speaker', 'This is the latest iMac', 500000.00, 'products/December2020/7waxGMczElbTTvYFwxKK.jpg', 36, '2020-10-29 08:25:00', '2020-12-12 23:06:03', 3),
('Original SIlver Couple heart chain', '512GB iPhone 12 Pro Max  More camera depth', 900000.00, 'products/December2020/odXwuXXS3Uv9FUgJFQhu.jpg', 37, '2020-10-29 08:25:00', '2020-12-12 23:08:45', 1),
('iPhone 11 Pro Max 256Gb Unlocked', 'Fashion Bronze Jean.... Available in different colors', 900000.00, 'products/December2020/FqE2rBPhc29axY5kbuj8.jpg', 39, '2020-10-29 08:25:00', '2020-12-12 23:13:40', 4),
('Tecno Spark 4 Android Phone 64GB', 'Latest Tecno Phone with all the coolest and unique features', 100000.00, 'products/December2020/18AgvHQ4hdRA288zCMff.jpg', 40, '2020-10-29 08:25:00', '2020-12-15 10:30:54', 1),
('7000Amh Power Bank', 'High quality jeans', 20000.00, 'products/December2020/uBRyJx9yVrNKRBibydmE.jpg', 42, '2020-10-29 08:25:00', '2020-12-12 23:14:52', 4),
('Jvc Bluetooth Speaker', 'Very Soft material but robost to dust', 20000.00, 'products/December2020/ROzM7OE99wFivkxs5dqV.jpg', 152, '2020-10-29 10:17:00', '2020-12-12 23:08:03', 4),
('Male Italian Shoe', 'Original Leather Male shoe  Very durable and', 22000.00, 'products/December2020/kIt2JNOiBC7kd3C4vYby.jpg', 153, '2020-11-03 11:37:00', '2020-12-15 10:30:12', 1),
('Male Original Leather Belt', 'Original male belt for sale', 50000.00, 'products/December2020/dkM9n0flscHru08jwitx.jpg', 154, '2020-11-03 20:45:00', '2020-12-12 23:12:34', 4),
('Rolex Ice Watch', 'This is the coolest watch in town', 200000.00, 'products/December2020/hkmljBMKcH4PV0CsBOLV.jpg', 155, '2020-11-13 05:20:00', '2020-12-12 23:05:20', 4),
('Samsung Galaxy S10', 'The best in display and camera', 700000.00, 'products/December2020/qlzUC3BQFvuDBl4MG50o.jpg', 156, '2020-11-19 16:34:00', '2020-12-12 23:04:54', 1),
('Lenovo T440 SSD 256GB', 'Best Lapton in town', 500000.00, 'products/December2020/OMr92a68afJwywPCuZhh.jpg', 157, '2020-12-14 00:34:00', '2020-12-14 00:49:18', NULL),
('Sony DVD', 'Best dvd player', 30000.00, 'products/December2020/zNjTyHwX4jbi8fvHlnBF.jpg', 158, '2020-12-15 18:10:00', '2020-12-15 18:11:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `product_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 155, 7, NULL, NULL),
(2, 156, 3, NULL, NULL),
(4, 156, 9, NULL, NULL),
(5, 157, 10, NULL, NULL),
(6, 157, 4, NULL, NULL),
(7, 40, 3, NULL, NULL),
(8, 40, 9, NULL, NULL),
(9, 158, 5, NULL, NULL),
(10, 158, 6, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_table`
--

CREATE TABLE `purchase_table` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `cover_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shop_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recents`
--

CREATE TABLE `recents` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `cover_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shop_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recents`
--

INSERT INTO `recents` (`name`, `description`, `price`, `cover_img`, `id`, `created_at`, `updated_at`, `shop_id`) VALUES
('Lumia 1020', 'Cool and recently ordered', 200000.00, 'recents/December2020/zKvoBSQXi5fmriUZ2q4A.jpg', 1, '2020-12-14 20:41:00', '2020-12-14 21:00:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(2, 'user', 'Normal User', '2020-10-29 08:24:47', '2020-10-29 08:24:47'),
(3, 'seller', 'Seller', '2020-10-29 08:49:32', '2020-10-29 08:49:32');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `display_name`, `value`, `details`, `type`, `order`, `group`) VALUES
(1, 'site.title', 'Site Title', 'Site Title', '', 'text', 1, 'Site'),
(2, 'site.description', 'Site Description', 'Site Description', '', 'text', 2, 'Site'),
(3, 'site.logo', 'Site Logo', '', '', 'image', 3, 'Site'),
(4, 'site.google_analytics_tracking_id', 'Google Analytics Tracking ID', '', '', 'text', 4, 'Site'),
(5, 'admin.bg_image', 'Admin Background Image', '', '', 'image', 5, 'Admin'),
(6, 'admin.title', 'Admin Title', 'Voyager', '', 'text', 1, 'Admin'),
(7, 'admin.description', 'Admin Description', 'Welcome to Voyager. The Missing Admin for Laravel', '', 'text', 2, 'Admin'),
(8, 'admin.loader', 'Admin Loader', '', '', 'image', 3, 'Admin'),
(9, 'admin.icon_image', 'Admin Icon Image', '', '', 'image', 4, 'Admin'),
(10, 'admin.google_analytics_client_id', 'Google Analytics Client ID (used for admin dashboard)', '', '', 'text', 1, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` double(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`id`, `name`, `user_id`, `is_active`, `description`, `rating`, `created_at`, `updated_at`) VALUES
(1, 'Iphones', 2, 1, 'This shop is for selling all types of Iphones', NULL, '2020-10-29 08:51:00', '2020-10-29 08:55:58'),
(3, 'MacBook Pro', 3, 1, 'We sell all types of MacBooks and Macbook Pros', NULL, '2020-10-29 09:11:00', '2020-10-29 09:19:21'),
(4, 'Jean Trousers', 3, 1, 'We sell all types of jean trousers for male, female, kids adult etc.', NULL, '2020-10-29 09:29:00', '2020-11-03 20:49:53');

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `translations`
--

INSERT INTO `translations` (`id`, `table_name`, `column_name`, `foreign_key`, `locale`, `value`, `created_at`, `updated_at`) VALUES
(1, 'data_types', 'display_name_singular', 5, 'pt', 'Post', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(2, 'data_types', 'display_name_singular', 6, 'pt', 'Página', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(3, 'data_types', 'display_name_singular', 1, 'pt', 'Utilizador', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(4, 'data_types', 'display_name_singular', 4, 'pt', 'Categoria', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(5, 'data_types', 'display_name_singular', 2, 'pt', 'Menu', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(6, 'data_types', 'display_name_singular', 3, 'pt', 'Função', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(7, 'data_types', 'display_name_plural', 5, 'pt', 'Posts', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(8, 'data_types', 'display_name_plural', 6, 'pt', 'Páginas', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(9, 'data_types', 'display_name_plural', 1, 'pt', 'Utilizadores', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(10, 'data_types', 'display_name_plural', 4, 'pt', 'Categorias', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(11, 'data_types', 'display_name_plural', 2, 'pt', 'Menus', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(12, 'data_types', 'display_name_plural', 3, 'pt', 'Funções', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(13, 'categories', 'slug', 1, 'pt', 'categoria-1', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(14, 'categories', 'name', 1, 'pt', 'Categoria 1', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(15, 'categories', 'slug', 2, 'pt', 'categoria-2', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(16, 'categories', 'name', 2, 'pt', 'Categoria 2', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(17, 'pages', 'title', 1, 'pt', 'Olá Mundo', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(18, 'pages', 'slug', 1, 'pt', 'ola-mundo', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(19, 'pages', 'body', 1, 'pt', '<p>Olá Mundo. Scallywag grog swab Cat o\'nine tails scuttle rigging hardtack cable nipper Yellow Jack. Handsomely spirits knave lad killick landlubber or just lubber deadlights chantey pinnace crack Jennys tea cup. Provost long clothes black spot Yellow Jack bilged on her anchor league lateen sail case shot lee tackle.</p>\r\n<p>Ballast spirits fluke topmast me quarterdeck schooner landlubber or just lubber gabion belaying pin. Pinnace stern galleon starboard warp carouser to go on account dance the hempen jig jolly boat measured fer yer chains. Man-of-war fire in the hole nipperkin handsomely doubloon barkadeer Brethren of the Coast gibbet driver squiffy.</p>', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(20, 'menu_items', 'title', 1, 'pt', 'Painel de Controle', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(21, 'menu_items', 'title', 2, 'pt', 'Media', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(22, 'menu_items', 'title', 12, 'pt', 'Publicações', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(23, 'menu_items', 'title', 3, 'pt', 'Utilizadores', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(24, 'menu_items', 'title', 11, 'pt', 'Categorias', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(25, 'menu_items', 'title', 13, 'pt', 'Páginas', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(26, 'menu_items', 'title', 4, 'pt', 'Funções', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(27, 'menu_items', 'title', 5, 'pt', 'Ferramentas', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(28, 'menu_items', 'title', 6, 'pt', 'Menus', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(29, 'menu_items', 'title', 7, 'pt', 'Base de dados', '2020-10-29 08:24:49', '2020-10-29 08:24:49'),
(30, 'menu_items', 'title', 10, 'pt', 'Configurações', '2020-10-29 08:24:49', '2020-10-29 08:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `email_verified_at`, `password`, `remember_token`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ivan', 'admin@admin.com', 'users/December2020/uRw3yrEAUjkF47Fh9saP.png', NULL, '$2y$10$yQtA09TEX13CDZh6gwImp./ZUTH7WkOnI8BU5/BlFNZtav86YaTj6', 'q7MyiB0w7HsfENA7342EYTU8sOJr4lcgOGwrHxQMpsDS10jqmyFML2JON06E', '{\"locale\":\"en\"}', '2020-10-29 08:24:48', '2020-12-12 23:35:23'),
(2, 3, 'John Ston', 'johnston@gmail.com', 'users/December2020/Pvigli5kaBUFXRRtIzpQ.jpg', NULL, '$2y$10$/akBCXtN95A5ifSRPoMZhOIufrakU/04kk4zRoGSoYv/XISY/sJWi', NULL, '{\"locale\":\"en\"}', '2020-10-29 08:50:32', '2020-12-12 23:30:08'),
(3, 3, 'Eugene John', 'eugenejohn@gmail.com', 'users/December2020/G6swzAvnfhpsTBCCrshX.jpg', NULL, '$2y$10$om9AuoHH9oJOxC5ybBNdaeXHAhjespIIAHZdrNWVNeOqF7idGXCBi', NULL, '{\"locale\":\"en\"}', '2020-10-29 09:08:12', '2020-12-12 23:35:38'),
(4, 3, 'Cake Johnson', 'cake@gmail.com', 'users/December2020/biTlxwMo62k9eflNf8YB.jpg', NULL, '$2y$10$o5dUss1C2U2iYeissFz92.3hadZHl0oPTakGrjda3k2ERuP7IwYwG', NULL, '{\"locale\":\"en\"}', '2020-11-20 15:28:28', '2020-12-12 23:27:56'),
(5, 3, 'Skrilla Massaquoi', 'skrilla@gmail.com', 'users/December2020/rhv4IVajwGkvV2LTTv2q.jpg', NULL, '$2y$10$Nb4GDetq2CypvYXsTBfmkeNRNQtJ7AksCjC0c1HT0OVuTIRS2P6nG', NULL, '{\"locale\":\"en\"}', '2020-11-20 15:29:03', '2020-12-12 23:28:10');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `data_rows`
--
ALTER TABLE `data_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_rows_data_type_id_foreign` (`data_type_id`);

--
-- Indexes for table `data_types`
--
ALTER TABLE `data_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_types_name_unique` (`name`),
  ADD UNIQUE KEY `data_types_slug_unique` (`slug`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_key_index` (`key`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_shop_id_foreign` (`shop_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase_table`
--
ALTER TABLE `purchase_table`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_table_shop_id_foreign` (`shop_id`);

--
-- Indexes for table `recents`
--
ALTER TABLE `recents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shops_user_id_foreign` (`user_id`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `user_roles_user_id_index` (`user_id`),
  ADD KEY `user_roles_role_id_index` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `data_rows`
--
ALTER TABLE `data_rows`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `data_types`
--
ALTER TABLE `data_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `purchase_table`
--
ALTER TABLE `purchase_table`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recents`
--
ALTER TABLE `recents`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `data_rows`
--
ALTER TABLE `data_rows`
  ADD CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `purchase_table`
--
ALTER TABLE `purchase_table`
  ADD CONSTRAINT `purchase_table_shop_id_foreign` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shops`
--
ALTER TABLE `shops`
  ADD CONSTRAINT `shops_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
